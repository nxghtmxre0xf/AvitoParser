// tailwind.config.js
module.exports = {
  content: [
    "./public/**/*.{handlebars,js,css}",
    "./views/**/*.{handlebars,js,css}",
    "./node_modules/tw-elements/dist/js/**/*.js",
  ],
  darkMode: false,
  theme: {
    extend: {},
  },
  variants: {},
  plugins: [],
}