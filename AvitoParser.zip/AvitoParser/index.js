const express = require('express')
const hbars = require('express-handlebars')
const path = require('path')
const jsdom = require('jsdom')
const { JSDOM } = jsdom
const ppt = require('puppeteer')
const mysql = require('mysql')
const pkg = require('./package.json')

const PORT = 8080

const app = express()

const delay = ms => new Promise(resolve => setTimeout(resolve, ms))

//js-catalog-item-enum

// const db = mysql.createPool({
//     connectionLimit : 100,
//     host: "localhost",
//     user: "root",
//     password: "",
//     database: "avitoparser"
// })

// , 
//             ignoreHTTPSErrors: true,
//             args: [`--window-size=1920,1080`],
//             defaultViewport: {
//               width:1920,
//               height:1080
//             }

async function Parse(url) {
    try {
        const browser = await ppt.launch(
            { headless: true }
        )
        const page = await browser.newPage()
        await page.goto(url)
        await page.screenshot({path: 'ppt/ex.png'})

        let data = await page.evaluate(() => {
            return document.querySelector('body').outerHTML
        })

        await browser.close()

        const dom = new JSDOM(data)
        const doc = dom.window.document
        const items = doc.querySelectorAll('[data-marker=item]')

        const ads = {}
        const images = {}

        items.forEach(node => {

            let buffer = String(node.querySelector('[data-marker=item-photo]').querySelector('div > div > ul > li').getAttribute('data-marker').substring(19))

            ads[node.id] = {
                id: node.id,
                title: node.querySelector('[itemprop=name]').innerHTML,
                image: buffer,
                price: node.querySelector('[itemprop=price]').getAttribute('content'),
                url: 'https://www.avito.ru' + node.querySelector('[itemprop=url]').getAttribute('href'),
                date: node.querySelector('[data-marker=item-date]').innerHTML,
                description: node.querySelector('div > div > p').innerHTML,
            }
        })

        return ads
    }
    catch (error) {
        return {
            error: error,
            data: null
        }
    }
}

function GetIds(data) {
    const ids = {}

    let count = 0

    for(let el in data) {

        ids[count] = {
            id: el,
        }
        count++
    }

    return ids
}

app.engine('handlebars', hbars.engine())
app.set('view engine', 'handlebars')
app.set('views', path.join(__dirname, 'views'))
app.use(express.static(path.join(__dirname, 'public')))

app.get('/', (req, res) => {
    res.render('home/index', {version: pkg.version})
})

app.get('/changelog', (req, res) => {
    res.render('home/changelog', {layout: 'changelog', version: pkg.version})
})

app.get('/parse', async (req, res) => {

    let urlp = req.query.urlparse

    let data = await Parse(urlp)

    console.log(data)

    res.render('parse/index', {layout: 'blank', data: data})
})

app.use((req, res) => {
    res.send(`404 Not Found '${req.url}'`)
})

app.listen(PORT, (req, res) => {
    console.log(`Started: http://localhost:${PORT}`);
})