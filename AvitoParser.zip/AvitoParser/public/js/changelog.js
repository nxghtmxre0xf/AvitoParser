var Mouse = { x: -1, y: -1 }

$(function () {
    $(document).mousemove(function(event) {
        Mouse.x = event.pageX
        Mouse.y = event.pageY
    })

    $('.wrapper').click(() => {
        $('.context').css('display', 'none')
        $('.context').css('top', '0px')
        $('.context').css('left', '0px')
    })

    if (document.addEventListener) {
        document.addEventListener('contextmenu', function(e) {
          $('.context').css('display', 'flex')
          $('.context').css('top', Mouse.y)
          $('.context').css('left', Mouse.x)
          e.preventDefault()
        }, false)
    } else {
        document.attachEvent('oncontextmenu', function() {
        window.event.returnValue = false
    })
    }
})