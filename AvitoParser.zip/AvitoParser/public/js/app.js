let buffer, Update, lastAd

let __debug__ = false
let sound = true

let first = true

var Mouse = { x: -1, y: -1 }
//<pre>TimeoutError: Navigation timeout of 30000 ms exceeded</pre>

let banned = []

$(function () {
  Load()

  $('#debug-mode').html(`DEBUG MODE (${__debug__})`)

  $('#debug-mode').click(() => {
    __debug__ = !__debug__
    $('#debug-mode').html(`DEBUG MODE (${__debug__})`)
  })

  $('#sound-switch').html(`Звук (${sound})`)

  $('#sound-switch').click(() => {
    sound = !sound
    $('#sound-switch').html(`Звук (${sound})`)
  })

  $('#parse').on('click', () => {
    if($('#auto-update').prop('checked')) {
      Parse()
      Update = setInterval(Parse, $('#auto-time').val())
    }
    else {
      Parse()
      clearInterval(Update)
    }
  })

  $(document).mousemove(function(event) {
    Mouse.x = event.pageX
    Mouse.y = event.pageY
  })

  $('.wrapper').click(() => {
    $('.context').css('display', 'none')
    $('.context').css('top', '0px')
    $('.context').css('left', '0px')
  })

  $('.list-hidden').click(() => {
    Log(`Список скрытых объявлений: ${banned.join(', ') || 'Нет'}`, 'info')
  })

  if (document.addEventListener) {
    document.addEventListener('contextmenu', function(e) {
      $('.context').css('display', 'flex')
      $('.context').css('top', Mouse.y)
      $('.context').css('left', Mouse.x)
      e.preventDefault()
    }, false)
  } else {
    document.attachEvent('oncontextmenu', function() {
      window.event.returnValue = false
    })
  }

  $(document).on('click', '.hide-add', (e) => {
    HideAd($(e.target).closest('.item').attr('id'))
  })

  $('.clear-hidden ').click(() => {
    ClearHidden()
  })

  setInterval(() => {
    Save()
  }, 100)
})

const Load = () => {
  buffer = localStorage.getItem('buffer')
  banned = localStorage.getItem('banned').split(', ')
  $('#input').val(buffer)

  if(__debug__) Log(`[DEBUG] Local Storage загружен`, 'info')
}

const SaveInput = () => {
  localStorage.setItem('buffer', $('#input').val())
}

const Save = () => {
  localStorage.setItem('banned', banned.join(', '))
}

const Parse = (callback = () => {}) => {
  if(__debug__) Log('[DEBUG] Получение данных', 'info')
  SaveInput()
  $('.content').empty()
  $('.content').removeClass('justify-justify-start');
  $('.content').addClass('justify-center');
  $('.content').append(`
  <div class="loading">
      <span class="circle"></span>
      <span class="circle"></span>
      <span class="circle"></span>
      <span class="circle"></span>
  </div>
  `)
  $.get(window.location.href.split('/')[0] + 'parse', {urlparse: $('#input').val()},
  (data) => {
      $('.content').empty()
      $('.content').removeClass('justify-center');
      $('.content').addClass('justify-justify-start');
      $('.content').append(`${data}`)
  }
  ).then(() => {
    let dt = new Date()
    if(__debug__) Log(`[DEBUG] Данные получены - ${dt}`, 'info')
    CheckErrors()
    callback()
  })
}

const CheckErrors = () => {
  if(__debug__) Log('[DEBUG] Проверка на ошибки', 'info')
  let html = String($('.content').html())
  if(html == '<pre>TimeoutError: Navigation timeout of 30000 ms exceeded</pre>') {
    Log('Ошибка: Нет ответа сервера', 'bad')
    Parse(() => {
      CheckErrors()
    })
  }
  else if(html.slice(0, 5) == '<pre>') {
    Log('Ошибка', 'bad')
  }
  else {
    // if(sound) $.playSound('sound/parsed.mp3')
    CheckHidden()
    CompareAds()
  }
}

const CheckHidden = () => {
  if(__debug__) Log('[DEBUG] Проверка скрытых объявлений', 'info')
  $('.content .item').each((index, el) => {
    banned.forEach(item => {
      if(item == $(el).attr('id')) {
        if(__debug__) Log(`[DEBUG] Объект (#${item}) скрыт`, 'info')
        $(el).css('display', 'none')
      }
    })
  })
}

const HideAd = (id = undefined) => {

  let already = false

  banned.forEach(el => {
    if(el == id) {
      Log(`Объявление (#${id}) уже было добавлено в скрытые`, 'bad')
      already = true
    }
  })

  if(already) return

  banned.push(id)
  Log(`Объявление (#${id}) скрыто`, 'ok')
}

const ClearHidden = () => {
  banned = []
  Log(`Список скрытых объявлений успешно очищен`, 'ok')
}

const Log = (text = 'undefined', type = 'std', lifetime = 5000) => {
  let typeStr = ''
  switch (type) {
    case 'ok':
      typeStr = 'log-ok'
      break;
    case 'bad':
      typeStr = 'log-bad'
      break;
    case 'info':
      typeStr = 'log-info'
      break;
    case 'std':
      typeStr = ''
      break;
  
    default:
      typeStr = 'log-error'
      break;
  }

  $('.log').append(`
  <div class="log-item ${typeStr}">
      <p>${text}</p>
  </div>
  `)

  setTimeout(() => {
    $('.log-item:first-child').remove()
  }, lifetime)
}

const CompareAds = () => {

  if(__debug__) Log('[DEBUG] Сравнение объявлений', 'info')

  if(first) {
    lastAd = $('.content > div:first-child').attr('id')
    first = false
    return
  }

  if(lastAd != $('.content > div:first-child').attr('id')) {
    lastAd = $('.content > div:first-child').attr('id')
    Log('Найдено новое объявление', 'info')
    $.playSound('sound/notify.mp3')
  }
}